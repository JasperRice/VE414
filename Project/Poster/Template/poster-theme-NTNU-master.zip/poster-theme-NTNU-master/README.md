# poster-theme-NTNU
A Latex Poster Theme for NTNU students wanting to make posters of various sizes
